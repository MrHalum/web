<html >
<head>
<title>PHP | Test 3</title>
</head>
<form action="no3val.php" method="post">
<body>
   
   <fieldset style="width: 300px; height: 130px;" >
       <legend>DATE OF BIRTH</legend>
       <table>
           <tr>
           <td><p>dd</p></td>
           <td><p>mm</p></td>
           <td><p>yyyy</p></td>
             
           </tr>
           <tr>
               <td><input type="text"  name="date" style="width: 50px;"/>/</td>
               
               <td><input type="text"  name="month" style="width: 50px;"/>/</td>
               
               <td><input type="text"  name="year" style="width: 70px;"/></td>
           </tr>
           
       </table>
       <input type="submit" name="submit" value="Submit" />
       
   </fieldset>
   

 
    
</body>
    </form>
</html>