<?php
    
$date=$_REQUEST['date'];
$month=$_REQUEST['month'];
$year=$_REQUEST['year'];



    
if(isset($_POST['submit']))
{
    
    
      if(empty($date) && empty($month) && empty($year))
        {
            echo "Fillup All field";
        }
    
        elseif(empty($month) && empty($date))
        
        {
            echo " Day & Month field is empty";
        }
  
        elseif(empty($month) && empty($year))
        {
            echo "Month & Year field is empty";
        }
    
        elseif(empty($date) && empty($year))
        {
            echo "Day & Year field is empty";
        }
    
        elseif(empty($date))
        {
            echo "Date field is empty";
        }
        
        elseif($_POST["date"]<1 || $_POST["date"]>31)
		{
			echo "<br>";
			echo "Day must between 1-31";
		}
		
    
        elseif(empty($month))
        
        {
            echo "Month field is empty";
        }
    
        elseif($_POST["month"]<1 || $_POST["month"]>12)
		{
			echo "<br>";
			echo "Month must between 1-12";
		}
     
        elseif(empty($year))
        {
            echo "Year field is empty";
        }
    
        elseif($_POST["year"]<1953 || $_POST["year"]>1998)
		{
			echo "<br>";
			echo "Year must between 1953-1998";
		}
    
      elseif(!is_numeric($date)  || !is_numeric($month) || !is_numeric($year))
          
      {
           echo "Invalid";
      }
    
                else
                {
        
       
                   echo "Date Of Birth is :"."$date"."/"."$month"."/"."$year";

               } 
               
           }

else
{
    
}


?>