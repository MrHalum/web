<?php

if(isset($_POST['submit']))
{
  

if(empty($_REQUEST['name']))
{
	echo "Please write down you Name";
}

else
{
    $date=$_REQUEST['date'];
    $month=$_REQUEST['month'];
    $year=$_REQUEST['year'];
	$email=$_REQUEST['email']; 
    $cpass= $_REQUEST['confirmPassword'];
    $npass = $_REQUEST['password'];    
    $name=$_REQUEST['name'];
    $uname=$_REQUEST['userName'];
    
    
$n=$name[0];

if($n[0]>='A' && $n[0]<='Z')
{


	if( strlen($name)<2 )
	{
		echo "Input at least two characters";
	}
	
	else
	{
		
         if (!preg_match("/^[a-zA-Z ]*$/",$name)) 
            {
                echo " Name Only letters and white space allowed";
            }
        else
        {
            
            if(empty($_POST["email"]))
              
			{
             echo "Cannot be empty";
            }
          
			else
              
            {
                 if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
                 {
                echo "Invalid email format";
                }
                
                else
                {
                    if(empty($uname))
                        {
                            echo "Please Insert your username";
                        }
                    else
                    {
                        if( strlen($uname)<2 )
                            {
                                echo "userName include at least two characters";
                            }
                        
                        else
                        {
                            if(!preg_match('/^[a-zA-Z0-9 @$%#._-]+$/',$uname))
                            {
                                echo "Name can contain alpha numeric characters, period, dash or underscore only";
                            }
                            
                            
                            else
                            {
                                
                              if(empty($npass))
                                {
                                    echo "Please give your password";
                                }

                                elseif(empty($cpass))

                                {
                                    echo "confirm Password field is empty";
                                }
                                
                                else
                                {
                        if (strlen($npass)< 8 && strlen($cpass) < 8) 
                                 {
                                echo "Your Password Must Contain At Least 8 Characters!";
                                }
                                    
                                    else
                                    {
                                if(!preg_match("([@$%#+])",$npass,$cpass)) 
                                {
                            echo "Your Password Must Contain At Least 1  special characters (@, #, $, %)!";
                            }
                                        
                                        else
                                        {
                                            
                                    if( !$npass=== $cpass )
                                    {
                                        echo "Password should be same in both";
                                    }
                                            else
                                            {
                                                
                                    if(strlen(isset($_POST["gender"]))==0)
                                    {
                                        echo "Gender must be choosen";
                                    }
                                            else
                                            {
                                                
            if(empty($date) && empty($month) && empty($year))
        {
            echo "Fillup All field";
        }
    
        elseif(empty($month) && empty($date))
        
        {
            echo " Day & Month field is empty";
        }
  
        elseif(empty($month) && empty($year))
        {
            echo "Month & Year field is empty";
        }
    
        elseif(empty($date) && empty($year))
        {
            echo "Day & Year field is empty";
        }
                                                
        elseif(empty($date))
        {
            echo "Date field is empty";
        }
    
       elseif($_POST["date"]<1 || $_POST["date"]>31)
		{
			echo "<br>";
			echo "Day must between 1-31";
		}
		
    
        elseif(empty($month))
        
        {
            echo "Month field is empty";
        }
    
        elseif($_POST["month"]<1 || $_POST["month"]>12)
		{
			echo "<br>";
			echo "Month must between 1-12";
		}
     
        elseif(empty($_REQUEST['year']))
        {
            echo "Year field is empty";
        }
    
        elseif($_POST["year"]<1946 || $_POST["year"]>2000)
		{
			echo "<br>";
			echo "Year must between 1946-2000";
		}
    
      elseif(!is_numeric($date)  || !is_numeric($month) || !is_numeric($year))
          
      {
           echo "Invalid";
      }
               else
               {
                   
                echo "Name  :"."$name"."<br>";
                echo "Email :".$_POST["email"]."<br>";
                echo "User Name :".$_POST["userName"]."<br>";
                echo "Password :".$_POST["password"]."<br>";   
                echo "Gender :".$_POST["gender"]."<br>";
                echo "Date Of Birth is :"."$date"."/"."$month"."/"."$year";

               } 
               
 
                                               
                                            }
                                                                    }
                                        }
                                    }
                                    
                                }
                                
                            }

                        }

                    }
                    
                   
                }
                
            }
            
          
        }

	}

}
else
{
	echo "invalid!! Must be start with uppercase";
}
}
    }

else
{
    echo "Error";
}


  ?>