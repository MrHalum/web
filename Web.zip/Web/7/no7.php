<html >
<head>
<title>PHP | Test 7</title>
</head>
<form action="no7val.php" method="post">
<body>
   
   <fieldset style="width: 370px; height: 200px;" >
       <legend><h3>LOGIN</h3></legend>
       
       <table>
           <tr>
              <td>User Name :</td> <td> <input type="text" name="namebox" style="width: 200px;" /></td>
           </tr>
           <tr>
               <td>Password :</td><td><input type="password" name="passwordbox" style="width: 200px;" /></td>
           </tr>
       </table>
       
       <hr>
       
       <input type="checkbox" name="remenber" />Remenber Me
       <br/>
       <br/>
       <input type="submit" name="submit" value="Submit" />
       <a href=""> Forgot Password?</a>
       
   </fieldset>
   
   
</body>
    </form>
</html>