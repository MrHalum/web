<?php
$npass = $_REQUEST['passwordbox'];
$name=$_REQUEST['namebox'];

if(isset($_POST['submit']))
{
  

if(empty($name))
{
	echo "Insert your name";
}
    
    elseif(empty($npass))
        {
            echo "Insert your password";
        }

else
{

	if( strlen($name)<2 )
	{
		echo "Name include at least two characters";
	}
    
      elseif (strlen($npass)< 8 ) 
        {
        echo "Your Password Must Contain At Least 8 Characters!";
        }
    
	
	elseif(!preg_match('/^[a-zA-Z0-9 @$%#._-]+$/',$name))
        {
            echo "Name can contain alpha numeric characters, period, dash or underscore only";
        }
    
    elseif(!preg_match("([@$%#+])",$npass)) 
        {
        echo "Your Password Must Contain At Least 1  special characters (@, #, $, %)!";
        }
	
        else
        {
            echo "User Name :"."$name"."<br>";
            echo "Password is :"."$npass";
        }

	}

}



else
{
    echo "Error";
}



  ?>