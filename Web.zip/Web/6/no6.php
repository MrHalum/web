<html >
<head>
<title>PHP | Test 6</title>
</head>
<form action="no6val.php" method="post">
<body>
   
   <fieldset style="width: 300px; height: 140px;" >
       <legend><h3>BLOOD GROUP</h3></legend>
       
       <table>
           <tr>
              <td>
              <select name="bgroup">
                    <option value=""> </option>
					<option value="A+">A+</option>
					<option value="A-">A-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
					<option value="O+">O+</option>
                    <option value="O-">O-</option>
                    
                    
            </select>      
                </td>
           </tr>
       </table>
       
       <hr>
       <input type="submit" name="submit" value="Submit" />
       
   </fieldset>

    
</body>
    </form>
</html>