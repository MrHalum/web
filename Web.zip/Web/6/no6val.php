<?php

if(isset($_POST['submit']))
{
      
         if(empty($_POST["bgroup"]))
              
			{
             echo "Must be selected";
            }
			else
			{
				echo "Blood Group :".$_POST["bgroup"];
			}     
      
}   
else
{
    echo "Error";
}
?>