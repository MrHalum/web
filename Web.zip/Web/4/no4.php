<html >
<head>
<title>PHP | Test 4</title>
</head>
<form action="no4val.php" method="post">
<body>
   
   <fieldset style="width: 300px; height: 100px;" >
       <legend>GENDER</legend>
       
       <table>
           <tr>
               <td><input type="radio" name="gender" value = "male"/>Male</td>
               <td><input type="radio" name="gender" value = "female"/>Female</td>
               <td><input type="radio" name="gender" value = "other"/>Other</td>
           </tr>
       </table>
       
       <hr>
       <input type="submit" name="submit" value="Submit" />
       
   </fieldset>
   

    
</body>
    </form>
</html>