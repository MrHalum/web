<?php
    
    $gender =$_POST["gender"];
    
if(isset($_POST['submit']))
{
      if(empty($gender))
			{echo "Please choose your gender";}
			else
			{
				echo "<p>Gender :".$gender."</p>";
			}
}
else
{
    echo "Error";
}

?>