<?php

if(isset($_POST['submit']))
{
  
	$name=$_POST['namebox'];
	
	if(empty($name)){
		
		echo 'Please give your name';

    }
	
	if(preg_match('/^[a-zA-Z -]{2,}$/', $name)) {
		
		echo $name;
	}
	else{
		echo "only Alphabet and dash is allow";
	}
	


}
  ?>