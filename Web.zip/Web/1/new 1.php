<html >
<head>
<title>PHP | Test 1</title>
</head>
<form action="new 2.php" method="post">
<body>
   
 <fieldset style="width: 300px; height: 100px;" >
       <legend>Name</legend>
       
       <input type="text" name="namebox"style="width: 200px;"/>
       <hr>
       <input type="submit" name="submit" value="Submit" />
       
   </fieldset>
   
 
    
</body>
    </form>
</html>