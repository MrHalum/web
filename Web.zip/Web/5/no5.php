<html >
<head>
<title>PHP | Test 1</title>
</head>
<form action="no5val.php" method="post">
<body>
   
   <fieldset style="width: 300px; height: 140px; border:2px solid #6d6d6d; " >
       <legend><h3>DEGREE</h3></legend>
       
       <table>
           <tr>
               <td><input type="checkbox" name="ssc" value = "ssc"/>SSC</td>
               <td><input type="checkbox" name="hsc" value = "hsc"/>HSC</td>
               <td><input type="checkbox" name="bsc" value = "bsc"/>BSc</td>
               <td><input type="checkbox" name="msc" value = "msc"/>MSc</td>
           </tr>
       </table>
       
       <hr>
       <input type="submit" name="submit" value="Submit" />
       
   </fieldset>
   

 
    
</body>
    </form>
</html>