<?php
    
    $count = 0;
    
if(isset($_POST['submit']))
{
      
		
		if(isset($_POST['ssc']))
		{
			echo "<br>";
			echo $_POST['ssc'];
			$count++;
		}
		if(isset($_POST['hsc']))
		{
			echo "<br>";
			echo $_POST['hsc'];
			$count++;
		}
		if(isset($_POST['bsc']))
		{
			echo "<br>";
			echo $_POST['bsc'];
			$count++;
		}
		if(isset($_POST['msc']))
		{
			echo "<br>";
			echo $_POST['msc'];
			$count++;
		}
		
		if($count <2)
		{
			echo "<br>";
			echo "Must select minimum 2 degree";
		}
	}
                
			

else
{
    echo "Error";
}

?>