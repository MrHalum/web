<html >
<head>
<title>PHP | Test 2</title>
</head>
<form action="no2val.php" method="post">
<body>
   
   <fieldset style="width: 300px; height: 130px;" >
       <legend>Email</legend>
       
       <input type="text" name="tbox1" style="width: 200px;"/> 
       <h3 style="display: inline-block;" ><abbr title="hint: sample@example.com"><b>i</b></abbr></h3>
       
       <hr>
       <input type="submit" name="submit" value="Submit" />
       
   </fieldset>
   
 
    
</body>
    </form>
</html>