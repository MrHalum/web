<?php
    
    $emailbox=$_POST["tbox1"];
   $email=$_REQUEST['tbox1']; 
   
   
   
if(isset($_POST['submit']))
{			
			
			
         if(empty($emailbox))
              
			{
             echo "Cannot be empty";
            }
          
			else
              
            {
                 if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
                 {
                echo "Invalid email format";
                }
                
                else
                {
                    echo "<p>Email :".$emailbox."</p>";
                }
                
            }
			   
      
}
   

else
{
    echo "Error";
}

?>