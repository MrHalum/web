<?php

$cpass= $_REQUEST['c_pass'];
$npass = $_REQUEST['n_pass'];
$confpass = $_REQUEST['conf_pass'];

if(isset($_POST['submit']))
{
    
    
      if(empty($cpass))
        {
            echo "current Password field is empty";
        }
    
        elseif(empty($npass))
        
        {
            echo "New Password field is empty";
        }

        elseif(empty($confpass))
        
        {
            echo "Retype New Password field is empty";
        }
      
    
    else
    {
        if (empty($npass) && empty($confpass) < 8) 
         {
        echo "Your Password Must Contain At Least 8 Characters!";
        }
        
        

			elseif( $_POST["c_pass"]=== $_POST["n_pass"] )
			{
				echo "New Password should not be same as the Current Password";
			}
			
			else
			{
				
		         if ($_POST["n_pass"]=== $_POST["conf_pass"]) 
		            {
		                echo " Your Password is Successfully changed";
		            }
                
		        else
		        {
		            echo "Your New Password and Retyped New Password is not same";
		        }
			
		   
			
			}


    }
    
}
else
{
	echo "invalid";
}



 ?>