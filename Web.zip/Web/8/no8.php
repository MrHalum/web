<html >
<head>
<title>PHP | Test 8</title>
</head>
<form action="no8val.php" method="post">
<body>
   
   <fieldset style="width: 370px; height: 200px;" >
       <legend><h3>CHANGE PASSWORD</h3></legend>
       
       <table>
           <tr>
              <td>Current Password </td><td>: <input type="password" name="c_pass" style="width: 200px;" /></td>
           </tr>
           <tr>
               <td style="color: green;" >New Password </td><td>: <input type="password" name="n_pass" style="width: 200px;" /></td>
           </tr>
           <tr>
                <td style="color: red;" >Retype New Password </td><td>: <input type="password" name="conf_pass" style="width: 200px;" /></td>
           </tr>
       </table>
       
       <hr>
       
       <input type="submit" name="submit" value="Submit" />
       
       
   </fieldset>
   

 
    
</body>
    </form>
</html>